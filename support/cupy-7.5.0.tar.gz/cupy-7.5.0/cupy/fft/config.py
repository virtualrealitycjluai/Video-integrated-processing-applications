
global enable_nd_planning
enable_nd_planning = True
