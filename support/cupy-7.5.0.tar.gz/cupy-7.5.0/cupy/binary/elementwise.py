from cupy import core


bitwise_and = core.bitwise_and


bitwise_or = core.bitwise_or


bitwise_xor = core.bitwise_xor


invert = core.invert


left_shift = core.left_shift


right_shift = core.right_shift
