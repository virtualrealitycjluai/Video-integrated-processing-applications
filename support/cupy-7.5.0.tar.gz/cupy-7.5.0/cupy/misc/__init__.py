from cupy.misc.memory_ranges import may_share_memory  # NOQA
from cupy.misc.memory_ranges import shares_memory  # NOQA
