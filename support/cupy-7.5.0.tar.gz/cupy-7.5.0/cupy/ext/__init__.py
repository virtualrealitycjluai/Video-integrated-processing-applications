# "NOQA" to suppress flake8 warning
from cupy.ext import scatter  # NOQA
